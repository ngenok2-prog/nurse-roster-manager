# How to Create a GitHub Account - Complete Guide

This guide will walk you through creating a GitHub account step-by-step. GitHub is a platform where you can store your code online and deploy it to Netlify.

## What is GitHub?

GitHub is a website where developers store their code projects. Think of it like Google Drive, but specifically designed for code. It allows you to:

- Store your project files online
- Share your code with others
- Deploy your app to Netlify
- Track changes to your code
- Collaborate with other developers

## Step 1: Open GitHub Website

1. Open your web browser (Chrome, Firefox, Safari, Edge, etc.)
2. Go to **https://github.com**
3. You should see the GitHub homepage with a "Sign up" button

## Step 2: Click "Sign up"

1. Look at the top-right corner of the page
2. Click the **"Sign up"** button (it's usually blue)
3. You'll be taken to the signup page

## Step 3: Enter Your Email Address

1. You'll see a field that says **"Email address"**
2. Enter your email address (e.g., yourname@gmail.com)
3. Make sure you use an email you have access to (you'll need to verify it)
4. Click **"Continue"**

## Step 4: Create a Password

1. GitHub will ask you to create a password
2. Enter a strong password that includes:
   - At least 8 characters
   - A mix of uppercase and lowercase letters
   - Numbers (0-9)
   - Special characters (!@#$%^&*)
3. Example of a strong password: `MyApp2024!Secure`
4. Click **"Continue"**

## Step 5: Choose a Username

1. GitHub will ask for a username (this is your GitHub identity)
2. Enter a username you like (it will be in your repository URLs)
3. Good examples:
   - `john-smith` (use hyphens, not spaces)
   - `jsmith2024`
   - `nurseapp-dev`
4. GitHub will show if the username is available (green checkmark = available)
5. Click **"Continue"**

## Step 6: Verify Your Email

1. GitHub will send a verification code to your email address
2. Check your email inbox (may take 1-2 minutes)
3. Look for an email from GitHub with subject "GitHub Verification Code"
4. Copy the 6-digit code from the email
5. Paste it into the GitHub verification field
6. Click **"Verify"**

## Step 7: Complete Your Profile

1. GitHub will ask a few questions:
   - **"Are you a student?"** → Select "No" (unless you are)
   - **"What do you plan to use GitHub for?"** → Select "For work"
   - **"How many team members will be using GitHub?"** → Select "Just me"
2. Click **"Continue"**

## Step 8: Choose Your Plan

1. GitHub will show three plan options:
   - **Free** (recommended for you)
   - **Pro** ($4/month)
   - **Team** ($21/month per user)
2. Click **"Choose Free"**
3. Done! Your GitHub account is created!

## What You'll See Next

After signup, you'll see your GitHub dashboard. This is your GitHub home page where you can:

- Create new repositories (projects)
- View your existing projects
- See activity from other developers
- Explore public projects

## Important: Save Your Login Information

Write down or save the following information somewhere safe:

- **Email**: The email you used to sign up
- **Username**: Your GitHub username
- **Password**: Your GitHub password (or use your browser's password manager)

You'll need this information to:
1. Create a repository for your Nurse Roster Manager
2. Deploy to Netlify
3. Update your code in the future

## Next Steps

Now that you have a GitHub account, you're ready to:

1. **Create a repository** for your Nurse Roster Manager
2. **Upload your code** to GitHub
3. **Deploy to Netlify** (which will automatically connect to your GitHub repository)

## Troubleshooting

### Email Not Received
- Check your spam/junk folder
- Wait 5 minutes (emails can be slow)
- Try requesting a new verification code
- Use a different email address

### Username Already Taken
- GitHub usernames must be unique
- Try adding numbers or hyphens
- Examples: `nurseapp`, `nurseapp2024`, `nurse-app-dev`

### Password Not Strong Enough
- GitHub requires strong passwords
- Add uppercase letters, numbers, and symbols
- Make it at least 8 characters long

### Can't Remember Your Password
- Go to github.com/login
- Click "Forgot password?"
- Follow the reset instructions sent to your email

## Security Tips

To keep your GitHub account safe:

1. **Use a strong password** (at least 12 characters)
2. **Don't share your password** with anyone
3. **Enable two-factor authentication** (optional but recommended):
   - Go to Settings → Security
   - Click "Enable two-factor authentication"
   - Follow the instructions
4. **Keep your email updated** so you can recover your account if needed

## What's Next?

Once your GitHub account is ready:

1. Go to the next guide: **GITHUB_REPOSITORY_SETUP.md** (coming soon)
2. Or follow the **NETLIFY_DEPLOYMENT.md** guide to deploy your app

## FAQ

**Q: Is GitHub free?**
A: Yes! The free plan is perfect for individuals and small projects. You can upgrade later if needed.

**Q: Can I delete my GitHub account?**
A: Yes, but it's permanent. Go to Settings → Account → Delete account.

**Q: Do I need to use GitHub?**
A: Not necessarily, but it's the easiest way to deploy to Netlify. Netlify works best with GitHub.

**Q: Can I have multiple GitHub accounts?**
A: Technically yes, but GitHub's terms of service recommend one account per person.

**Q: Is my code private on GitHub?**
A: By default, your repositories are public (anyone can see them). You can make them private in repository settings.

## Support

If you get stuck:

1. **GitHub Help**: https://docs.github.com/en/get-started
2. **GitHub Support**: https://support.github.com
3. **Ask in GitHub Discussions**: https://github.com/github/community/discussions

---

**Congratulations!** You now have a GitHub account! 🎉

Next step: Create a repository and upload your Nurse Roster Manager code.
