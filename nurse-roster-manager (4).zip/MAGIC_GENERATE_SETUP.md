# Magic Generate Setup Guide

## Overview

The **Magic Generate** feature uses OpenAI's GPT models to automatically create optimal nurse rosters based on intelligent scheduling constraints. This guide walks you through setting up and using this powerful feature.

## Prerequisites

Before you begin, ensure you have:

- An active OpenAI account with API access
- A valid API key from OpenAI
- Access to the Nurse Roster Manager application
- At least one nurse added to the system

## Step 1: Get Your OpenAI API Key

### 1.1 Create an OpenAI Account

If you don't already have an OpenAI account, visit [OpenAI's website](https://platform.openai.com/signup) and create one. You'll need to provide your email and set up payment information.

### 1.2 Generate an API Key

1. Log in to your OpenAI account at [platform.openai.com](https://platform.openai.com)
2. Click on your profile icon in the top-right corner
3. Select **"API keys"** from the dropdown menu
4. Click the **"Create new secret key"** button
5. Copy the generated API key and store it securely (you won't be able to see it again)

> **Security Note:** Never share your API key publicly or commit it to version control. Treat it like a password.

### 1.3 Set Up Billing

Ensure your OpenAI account has billing enabled:

1. Go to [Billing Overview](https://platform.openai.com/account/billing/overview)
2. Add a payment method if you haven't already
3. Set usage limits to control costs (optional but recommended)

## Step 2: Configure Magic Generate in the App

### Option A: Using the App HTML File (Temporary)

If you're using the standalone `app.html` file:

1. Open `app.html` in a text editor
2. Find line 180 (approximately) where you see:
   ```javascript
   const OPENAI_API_KEY = 'YOUR_OPENAI_API_KEY';
   const OPENAI_API_BASE = 'https://api.openai.com/v1';
   ```
3. Replace `'YOUR_OPENAI_API_KEY'` with your actual OpenAI API key:
   ```javascript
   const OPENAI_API_KEY = 'sk-proj-xxxxxxxxxxxxxxxxxxxxx';
   const OPENAI_API_BASE = 'https://api.openai.com/v1';
   ```
4. Save the file
5. Refresh your browser to load the updated configuration

> **Warning:** This method is NOT recommended for production use as it exposes your API key in the client-side code. Use this only for testing and development.

### Option B: Using Environment Variables (Recommended for Production)

For the React-based deployment, set environment variables:

1. Create a `.env.local` file in your project root:
   ```
   VITE_OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxx
   VITE_OPENAI_API_BASE=https://api.openai.com/v1
   ```

2. Update the app to read from environment variables instead of hardcoded values

3. Restart your development server:
   ```bash
   npm run dev
   ```

### Option C: Using a Backend Proxy (Most Secure)

For maximum security in production, create a backend endpoint that handles API calls:

1. Create a backend route that accepts roster data and returns generated schedules
2. The backend securely stores and uses your OpenAI API key
3. The frontend calls your backend endpoint instead of OpenAI directly
4. This prevents your API key from being exposed to users

## Step 3: Use Magic Generate

### 3.1 Prepare Your Data

Before generating a roster:

1. **Add Nurses**: Click "Add Nurse" and enter at least 3-5 nurses with their names and departments
2. **Select Month**: Use the month selector to choose the month you want to schedule
3. **Clear Existing Roster** (optional): If you have an existing roster, you can keep it and the AI will enhance it, or clear it first for a fresh generation

### 3.2 Generate the Roster

1. Click the **"Magic Generate"** button (blue button with a sparkle icon)
2. The app will send your nurse data and constraints to OpenAI
3. Wait for the AI to process (typically 5-15 seconds)
4. The generated roster will automatically populate in the table
5. A success message will appear: "Roster generated successfully with AI!"

### 3.3 Review and Adjust

After generation:

1. **Review Coverage**: Check the coverage metrics at the bottom of the page
2. **Verify Constraints**: Ensure the roster meets your requirements
3. **Manual Adjustments**: Click any cell to manually adjust shifts if needed
4. **Export**: Click "Export Excel" to save the roster

## Step 4: Understanding the AI Constraints

The Magic Generate feature balances six intelligent constraints:

| Constraint | Description | Impact |
| :--- | :--- | :--- |
| **Fair Distribution** | Each nurse gets 4-5 days off per month | Prevents overworking nurses |
| **Shift Spacing** | No Early shifts immediately after Night shifts | Protects nurse health and safety |
| **Coverage Targets** | At least 3 nurses per shift type daily | Ensures adequate staffing |
| **Equitable Scheduling** | Shifts distributed fairly among all nurses | Maintains team morale |
| **Department Awareness** | Respects department assignments | Maintains organizational structure |
| **Weekend Preference** | Weekends as days off or lighter shifts | Improves work-life balance |

## Troubleshooting

### Issue: "Please replace YOUR_OPENAI_API_KEY with your actual OpenAI API key"

**Solution:** You haven't configured your API key yet. Follow Step 2 above to add your OpenAI API key.

### Issue: "Failed to generate roster. Error: 401 Unauthorized"

**Causes:**
- Your API key is incorrect or expired
- Your OpenAI account doesn't have billing enabled
- Your API key has been revoked

**Solution:** 
1. Verify your API key is correct
2. Check your OpenAI account billing status
3. Generate a new API key if needed

### Issue: "Failed to generate roster. Error: 429 Rate Limited"

**Cause:** You've exceeded OpenAI's rate limits

**Solution:**
- Wait a few minutes before trying again
- Check your OpenAI usage at [platform.openai.com/account/billing/usage](https://platform.openai.com/account/billing/usage)
- Consider upgrading your OpenAI plan if you frequently hit rate limits

### Issue: "Failed to generate roster. Error: 500 Internal Server Error"

**Cause:** OpenAI service is experiencing issues

**Solution:**
- Wait a few minutes and try again
- Check [OpenAI's status page](https://status.openai.com/)

### Issue: Generated roster doesn't meet my expectations

**Solutions:**
1. **Adjust Constraints**: Modify the prompt in the code to prioritize different constraints
2. **Manual Refinement**: Use the UI to manually adjust shifts after generation
3. **Try Again**: The AI may produce different results on subsequent runs due to randomness

## Cost Estimation

OpenAI API calls are charged based on tokens used. Here's an approximate cost breakdown:

| Model | Cost per 1K Input Tokens | Cost per 1K Output Tokens |
| :--- | :--- | :--- |
| GPT-4o mini | $0.00015 | $0.0006 |
| GPT-4 Turbo | $0.01 | $0.03 |
| GPT-4 | $0.03 | $0.06 |

**Typical roster generation costs:**
- Small team (5 nurses, 1 month): ~$0.01-0.05
- Medium team (10 nurses, 1 month): ~$0.02-0.10
- Large team (20+ nurses, 1 month): ~$0.05-0.20

To minimize costs, use the GPT-4o mini model (recommended) or set usage limits in your OpenAI account.

## Advanced Configuration

### Changing the AI Model

To use a different OpenAI model, update the model name in the code:

```javascript
const response = await openai.chat.completions.create({
  model: "gpt-4o-mini",  // Change this to your preferred model
  // ... rest of configuration
});
```

Available models:
- `gpt-4o-mini` (recommended for cost-effectiveness)
- `gpt-4-turbo`
- `gpt-4`
- `gpt-3.5-turbo`

### Customizing Constraints

To modify scheduling constraints, edit the prompt in the `autoGenerateRoster` function:

```javascript
const prompt = `
  // ... existing prompt ...
  
  Constraints and Preferences (prioritize these):
  1. [Your custom constraint here]
  2. [Your custom constraint here]
  // ... etc
`;
```

## Best Practices

1. **Test First**: Generate a test roster with a small team before deploying to production
2. **Review Carefully**: Always review AI-generated rosters before publishing
3. **Set Usage Limits**: Configure spending limits in your OpenAI account to avoid unexpected charges
4. **Keep API Key Secure**: Never commit your API key to version control
5. **Monitor Usage**: Regularly check your OpenAI usage dashboard
6. **Backup Rosters**: Export rosters to Excel for backup and archival

## Security Considerations

### For Development

Using hardcoded API keys is acceptable for local development and testing only.

### For Production

**Never expose your API key in client-side code.** Instead:

1. **Use a Backend Proxy**: Create a secure backend endpoint that handles OpenAI API calls
2. **Use Environment Variables**: Store your API key in secure environment variables
3. **Implement Authentication**: Require user login before accessing Magic Generate
4. **Rate Limiting**: Implement rate limiting to prevent abuse
5. **Audit Logging**: Log all roster generation requests for compliance

## Support & Resources

- **OpenAI Documentation**: [platform.openai.com/docs](https://platform.openai.com/docs)
- **API Reference**: [platform.openai.com/docs/api-reference](https://platform.openai.com/docs/api-reference)
- **Pricing**: [openai.com/pricing](https://openai.com/pricing)
- **Status Page**: [status.openai.com](https://status.openai.com/)

## FAQ

**Q: Can I use a different AI provider instead of OpenAI?**

A: Yes, you can modify the code to use other providers like Anthropic's Claude, Google's Gemini, or open-source models. The prompt engineering principles remain the same.

**Q: What happens if the AI generates an invalid roster?**

A: The roster is validated before being displayed. If invalid shifts are detected, they're logged to the browser console and skipped.

**Q: Can I use Magic Generate offline?**

A: No, Magic Generate requires an internet connection to communicate with OpenAI's API.

**Q: How long does roster generation take?**

A: Typically 5-15 seconds depending on team size and OpenAI's current load.

**Q: Can I generate rosters for multiple months at once?**

A: Currently, you must generate one month at a time. You can repeat the process for each month.

---

**Ready to use Magic Generate?** Follow the steps above to configure your OpenAI API key and start generating optimal rosters!
