import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useEffect } from "react";
import { Settings as SettingsIcon, Eye, EyeOff, Check, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export default function Settings() {
  const [apiKey, setApiKey] = useState("");
  const [showApiKey, setShowApiKey] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Load API key from localStorage on mount
  useEffect(() => {
    const savedKey = localStorage.getItem("openai_api_key");
    if (savedKey) {
      setApiKey(savedKey);
      setIsSaved(true);
    }
  }, []);

  const handleSaveApiKey = () => {
    if (!apiKey.trim()) {
      toast.error("API key cannot be empty");
      return;
    }

    if (!apiKey.startsWith("sk-")) {
      toast.error("Invalid API key format. OpenAI keys start with 'sk-'");
      return;
    }

    setIsLoading(true);
    // Simulate validation delay
    setTimeout(() => {
      localStorage.setItem("openai_api_key", apiKey);
      setIsSaved(true);
      setIsLoading(false);
      toast.success("API key saved successfully!");
    }, 500);
  };

  const handleClearApiKey = () => {
    if (confirm("Are you sure you want to delete the saved API key?")) {
      setApiKey("");
      setIsSaved(false);
      localStorage.removeItem("openai_api_key");
      toast.success("API key deleted");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 pt-24 pb-12 px-4">
      <div className="container max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <SettingsIcon className="w-8 h-8 text-blue-600" />
            <h1 className="text-4xl font-bold text-gray-900">Settings</h1>
          </div>
          <p className="text-gray-600">Configure your application settings and API keys</p>
        </div>

        {/* OpenAI API Key Section */}
        <div className="bg-white rounded-lg shadow-lg p-8 mb-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">OpenAI API Key</h2>
            <p className="text-gray-600">
              Enter your OpenAI API key to enable the Magic Generate feature for automatic roster scheduling.
            </p>
          </div>

          {/* Info Box */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-800">
                <p className="font-semibold mb-1">How to get your API key:</p>
                <ol className="list-decimal list-inside space-y-1 ml-2">
                  <li>Go to <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="underline hover:text-blue-900">platform.openai.com/api-keys</a></li>
                  <li>Click "Create new secret key"</li>
                  <li>Copy the key and paste it below</li>
                </ol>
              </div>
            </div>
          </div>

          {/* API Key Input */}
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              API Key
            </label>
            <div className="relative">
              <input
                type={showApiKey ? "text" : "password"}
                value={apiKey}
                onChange={(e) => {
                  setApiKey(e.target.value);
                  setIsSaved(false);
                }}
                placeholder="sk-proj-..."
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent pr-12"
              />
              <button
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
              >
                {showApiKey ? (
                  <EyeOff className="w-5 h-5" />
                ) : (
                  <Eye className="w-5 h-5" />
                )}
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Your API key is stored locally in your browser and never sent to our servers.
            </p>
          </div>

          {/* Status */}
          {isSaved && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-6 flex items-center gap-2">
              <Check className="w-5 h-5 text-green-600" />
              <span className="text-green-800 font-medium">API key is configured and ready to use</span>
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-3">
            <Button
              onClick={handleSaveApiKey}
              disabled={isLoading || !apiKey.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? "Saving..." : "Save API Key"}
            </Button>
            {isSaved && (
              <Button
                onClick={handleClearApiKey}
                variant="outline"
                className="text-red-600 border-red-200 hover:bg-red-50"
              >
                Delete Key
              </Button>
            )}
          </div>
        </div>

        {/* Usage Information */}
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Magic Generate Usage</h2>

          <div className="space-y-6">
            {/* How It Works */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">How It Works</h3>
              <p className="text-gray-600 mb-3">
                Once you've configured your OpenAI API key, you can use the "Magic Generate" feature to automatically create optimal nurse rosters. The AI considers multiple constraints:
              </p>
              <ul className="space-y-2 text-gray-600 ml-4">
                <li>✓ Fair shift distribution among nurses</li>
                <li>✓ Preventing back-to-back difficult shifts</li>
                <li>✓ Ensuring adequate daily coverage</li>
                <li>✓ Respecting department assignments</li>
                <li>✓ Balancing weekend assignments</li>
                <li>✓ Maintaining work-life balance</li>
              </ul>
            </div>

            {/* Pricing */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Pricing</h3>
              <p className="text-gray-600 mb-3">
                Each roster generation uses OpenAI's API and incurs a small cost. Typical costs:
              </p>
              <div className="bg-gray-50 rounded-lg p-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Small team (5 nurses)</span>
                  <span className="font-semibold">~$0.01-0.05</span>
                </div>
                <div className="flex justify-between">
                  <span>Medium team (10 nurses)</span>
                  <span className="font-semibold">~$0.02-0.10</span>
                </div>
                <div className="flex justify-between">
                  <span>Large team (20+ nurses)</span>
                  <span className="font-semibold">~$0.05-0.20</span>
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-3">
                Costs vary based on team size and OpenAI's current pricing. Check your OpenAI dashboard for exact usage.
              </p>
            </div>

            {/* Security */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Security</h3>
              <p className="text-gray-600">
                Your API key is stored securely in your browser's local storage and is never transmitted to our servers. Only your browser communicates directly with OpenAI's API.
              </p>
            </div>

            {/* Support */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Need Help?</h3>
              <p className="text-gray-600 mb-3">
                For more information about setting up Magic Generate, check out our comprehensive guide:
              </p>
              <a
                href="/MAGIC_GENERATE_SETUP.md"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block bg-blue-100 text-blue-700 px-4 py-2 rounded-lg hover:bg-blue-200 transition font-medium"
              >
                View Setup Guide →
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
