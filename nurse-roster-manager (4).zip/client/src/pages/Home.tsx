import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, Users, BarChart3, FileUp, Sparkles } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-md border-b border-gray-200 z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="text-2xl font-bold text-blue-600">🏥</div>
            <span className="text-xl font-bold text-gray-900">Nurse Roster Manager</span>
          </div>
          <div className="flex items-center gap-4">
            <a href="/app.html" className="text-gray-600 hover:text-gray-900 font-medium">
              App
            </a>
            <a href="/showcase.html" className="text-gray-600 hover:text-gray-900 font-medium">
              Showcase
            </a>

            <Button asChild size="sm">
              <a href="/app.html">Launch App</a>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full mb-6">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-semibold">AI-Powered Scheduling</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Intelligent Nurse <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Roster Management</span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Automate complex scheduling with AI-powered roster generation. Balance fairness, coverage, and constraints effortlessly.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
              <a href="/app.html" className="flex items-center gap-2">
                Launch Interactive App
                <ArrowRight className="w-5 h-5" />
              </a>
            </Button>
            <Button asChild variant="outline" size="lg">
              <a href="/showcase.html">View Showcase</a>
            </Button>
          </div>

          {/* Hero Image Placeholder */}
          <div className="bg-gradient-to-br from-blue-100 to-indigo-100 rounded-2xl p-8 shadow-lg">
            <div className="bg-white rounded-lg p-6 shadow-md">
              <div className="grid grid-cols-7 gap-1">
                {Array.from({ length: 35 }).map((_, i) => (
                  <div
                    key={i}
                    className={`h-8 rounded ${
                      i % 7 === 0
                        ? "bg-gray-200"
                        : i % 3 === 0
                        ? "bg-blue-200"
                        : i % 5 === 0
                        ? "bg-orange-200"
                        : "bg-green-200"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Powerful Features</h2>
            <p className="text-xl text-gray-600">Everything you need for intelligent scheduling</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="group p-8 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-200 transition">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">AI Auto-Generation</h3>
              <p className="text-gray-600">
                Click "Magic Generate" to create optimal rosters instantly with intelligent constraint balancing.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="group p-8 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-200 transition">
                <BarChart3 className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Real-Time Analytics</h3>
              <p className="text-gray-600">
                Monitor coverage metrics, identify gaps, and track shift distribution in real-time.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="group p-8 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-200 transition">
                <FileUp className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Smart Excel Sync</h3>
              <p className="text-gray-600">
                Seamlessly import and export rosters with dynamic column detection and validation.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="group p-8 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-orange-200 transition">
                <Users className="w-6 h-6 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Nurse Management</h3>
              <p className="text-gray-600">
                Easily add, organize, and manage nursing staff by department with auto-generated IDs.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="group p-8 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-pink-200 transition">
                <Sparkles className="w-6 h-6 text-pink-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Smart Constraints</h3>
              <p className="text-gray-600">
                6 intelligent scheduling constraints ensure fairness, coverage, and nurse well-being.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="group p-8 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-indigo-200 transition">
                <ArrowRight className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Responsive Design</h3>
              <p className="text-gray-600">
                Works perfectly on desktop, tablet, and mobile with an intuitive, accessible interface.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4">
        <div className="container max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-16 text-center">How It Works</h2>
          
          <div className="space-y-8">
            {[
              {
                step: 1,
                title: "Add Your Team",
                description: "Input nurse names, departments, and employee IDs into the system.",
              },
              {
                step: 2,
                title: "Select Month",
                description: "Choose the month you want to schedule using the date picker.",
              },
              {
                step: 3,
                title: "Generate or Assign",
                description: "Click 'Magic Generate' for AI scheduling, or manually assign shifts.",
              },
              {
                step: 4,
                title: "Review & Export",
                description: "Check coverage metrics and export to Excel for sharing or archiving.",
              },
            ].map((item) => (
              <div key={item.step} className="flex gap-6">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-12 w-12 rounded-full bg-blue-600 text-white font-bold text-lg">
                    {item.step}
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Shift Legend */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="container max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">Shift Types</h2>
          
          <div className="grid md:grid-cols-3 gap-4">
            {[
              { code: "E", name: "Early", time: "6AM-2PM", color: "bg-yellow-100 text-yellow-800" },
              { code: "A", name: "Afternoon", time: "2PM-10PM", color: "bg-orange-100 text-orange-800" },
              { code: "N", name: "Night", time: "10PM-6AM", color: "bg-indigo-100 text-indigo-800" },
              { code: "DO", name: "Day Off", time: "Full Day", color: "bg-green-100 text-green-800" },
              { code: "PH", name: "Public Holiday", time: "Full Day", color: "bg-red-100 text-red-800" },
              { code: "H", name: "Half Day", time: "Half Day", color: "bg-purple-100 text-purple-800" },
            ].map((shift) => (
              <div key={shift.code} className={`p-4 rounded-lg ${shift.color} text-center`}>
                <div className="text-2xl font-bold mb-2">{shift.code}</div>
                <div className="font-semibold">{shift.name}</div>
                <div className="text-sm opacity-75">{shift.time}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="container max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-12 text-center text-white">
            <h2 className="text-4xl font-bold mb-4">Ready to Optimize Your Scheduling?</h2>
            <p className="text-lg mb-8 opacity-90">
              Start using AI-powered roster management today. No setup required.
            </p>
            <Button asChild size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              <a href="/app.html" className="flex items-center gap-2">
                Launch the App Now
                <ArrowRight className="w-5 h-5" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12 px-4">
        <div className="container max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="text-2xl">🏥</div>
                <span className="font-bold text-white">Nurse Roster Manager</span>
              </div>
              <p className="text-sm">AI-powered scheduling for healthcare professionals.</p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="/app.html" className="hover:text-white">App</a></li>
                <li><a href="/showcase.html" className="hover:text-white">Showcase</a></li>
                <li><a href="/IMPROVEMENTS.md" className="hover:text-white">Documentation</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Features</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="/app.html" className="hover:text-white">AI Generation</a></li>
                <li><a href="/app.html" className="hover:text-white">Analytics</a></li>
                <li><a href="/app.html" className="hover:text-white">Excel Sync</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="/showcase.html" className="hover:text-white">Guide</a></li>
                <li><a href="/IMPROVEMENTS.md" className="hover:text-white">Technical Docs</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>© 2026 Nurse Roster Manager. Built with ❤️ for healthcare professionals.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
