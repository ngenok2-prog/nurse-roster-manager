# Nurse Roster Manager

A modern, feature-rich web application for managing nurse schedules, shift assignments, and swap requests. Built with React, Tailwind CSS, and localStorage for offline support.

## Features

- **Interactive Roster Management**: Drag-and-drop style shift assignments with visual feedback
- **Shift Types**: Early (E), Afternoon (A), Night (N), Day Off (DO), Public Holiday (PH), Half Day (H)
- **Shift Swap Requests**: Nurses can request shift swaps with approval workflow
- **Excel Import/Export**: Import nurse lists and export rosters to Excel
- **Print-Friendly View**: Generate professional rosters for printing
- **Coverage Analytics**: Real-time coverage statistics and low-coverage alerts
- **Offline Support**: All data stored locally in browser
- **Responsive Design**: Works on desktop, tablet, and mobile devices

## Quick Start

### Prerequisites
- Node.js 18+ 
- pnpm (or npm/yarn)

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/nurse-roster-manager.git
cd nurse-roster-manager

# Install dependencies
pnpm install

# Start development server
pnpm dev
```

The app will be available at `http://localhost:3000`

### Build for Production

```bash
pnpm build
pnpm preview
```

## Deployment

### Deploy to Netlify

1. **Create a GitHub Account** (if you don't have one)
   - Go to github.com and sign up

2. **Connect to Netlify**
   - Go to netlify.com and sign up
   - Click "Connect to Git" → Select GitHub
   - Authorize Netlify to access your repositories
   - Select this repository
   - Click "Deploy"

3. **Add Custom Domain** (Optional)
   - Buy a domain from Namecheap, GoDaddy, or Google Domains
   - In Netlify dashboard → Domain settings
   - Add your custom domain
   - Follow DNS configuration instructions

### Deploy to Manus

1. Click the "Publish" button in the Management UI
2. Choose your domain name
3. Your app is live!

## Usage

### Adding Nurses
1. Click "Add Nurse" button
2. Enter nurse name, department, and employee ID
3. Click "Add Nurse"

### Assigning Shifts
1. Click on any cell in the roster table
2. Select a shift type from the dropdown
3. The date will be displayed for clarity
4. Shift is automatically saved

### Managing Swap Requests
1. Click "New Swap Request" button
2. Select your name, date, and the nurse to swap with
3. Add optional reason
4. Submit request
5. Managers can approve or reject requests

### Exporting Data
- **Excel**: Click "Export Excel" to download roster as .xlsx file
- **Print**: Click "Print Roster" to generate print-friendly view

## Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS 4
- **UI Components**: shadcn/ui, Radix UI
- **State Management**: React Context + localStorage
- **Build Tool**: Vite
- **Export**: XLSX (Excel), Native Print API

## File Structure

```
client/
├── public/
│   ├── app.html          # Main roster app
│   ├── showcase.html     # Feature showcase
│   └── images/           # Static images
├── src/
│   ├── pages/            # Page components
│   ├── components/       # Reusable components
│   ├── contexts/         # React contexts
│   ├── lib/              # Utilities
│   ├── App.tsx           # Main app component
│   ├── main.tsx          # React entry point
│   └── index.css         # Global styles
package.json
vite.config.ts
tsconfig.json
```

## Features in Detail

### Shift Management
- Color-coded shifts for quick visual identification
- Weekend highlighting
- Days off calculation and tracking
- Coverage summary with daily shift counts

### Swap Requests
- Submit requests with reason
- Track request status (Pending/Approved/Rejected)
- Approve/reject interface for managers
- Persistent storage across sessions

### Data Persistence
- All data saved to browser's localStorage
- Automatic sync status indicator
- Offline functionality
- One-click export to Excel

## Browser Support

- Chrome/Edge 90+
- Firefox 88+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Keyboard Shortcuts

- `Esc` - Close shift dropdown
- `Click outside` - Close any modal

## Troubleshooting

### Data Not Saving
- Check browser's localStorage is enabled
- Clear cache and refresh
- Try a different browser

### Import Issues
- Ensure Excel file has "Name" and "Department" columns
- Check file format is .xlsx or .xls
- Verify no special characters in nurse names

### Print Issues
- Use Chrome or Firefox for best results
- Disable browser extensions if print preview is blank
- Ensure printer is connected

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

MIT License - feel free to use this project for commercial purposes.

## Support

For issues, questions, or feature requests, please create an issue in the GitHub repository.

## Monetization

This app is ready to sell as a SaaS product. Suggested pricing:
- **Basic**: $49/month (up to 20 nurses)
- **Pro**: $99/month (up to 50 nurses)  
- **Enterprise**: Custom pricing (unlimited)

## Changelog

### v1.0.0 (Current)
- Initial release
- Roster management with shift assignments
- Shift swap request system
- Excel import/export
- Print-friendly view
- Responsive design
- Offline support

---

**Built with ❤️ for healthcare professionals**
