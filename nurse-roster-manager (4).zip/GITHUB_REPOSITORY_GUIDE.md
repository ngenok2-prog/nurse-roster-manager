# How to Create a GitHub Repository - Complete Guide

This guide will walk you through creating a GitHub repository (project folder) where you'll store your Nurse Roster Manager code.

## What is a Repository?

A **repository** (or "repo") is like a folder on GitHub where you store your project files. Think of it as a cloud storage folder specifically designed for code. Your repository will contain:

- All your project files (HTML, CSS, JavaScript, etc.)
- Project documentation (README files)
- Version history (track changes over time)
- Deployment configuration

## Prerequisites

Before creating a repository, make sure you:

1. Have a GitHub account (if not, follow the GITHUB_SETUP_GUIDE.md)
2. Are logged into GitHub (go to github.com and sign in)
3. Have your Nurse Roster Manager code ready to upload

## Method 1: Create Repository via GitHub Website (Recommended)

This is the easiest method and requires no command-line knowledge.

### Step 1: Go to GitHub's New Repository Page

1. Open your web browser
2. Go to **https://github.com/new**
3. You'll see the "Create a new repository" form

### Step 2: Fill in Repository Details

On the "Create a new repository" page, you'll see several fields to fill in:

#### Repository Name
1. Find the field labeled **"Repository name"**
2. Enter: `nurse-roster-manager`
3. This name will appear in your repository URL
4. GitHub will show if the name is available

#### Description (Optional)
1. Find the field labeled **"Description"**
2. Enter a brief description of your project:
   - Example: `Modern web app for managing nurse schedules and shift assignments`
3. This helps others understand what your project does
4. This field is optional but recommended

#### Public or Private
1. You'll see two radio button options:
   - **Public** (anyone can see your code)
   - **Private** (only you can see your code)
2. Select **"Public"** (recommended for selling)
3. Public repositories look more professional and trustworthy

#### Initialize Repository
1. Check the box: **"Add a README file"**
   - This creates a README.md file automatically
   - README files explain what your project does
2. Check the box: **"Add .gitignore"**
   - Select **"Node"** from the dropdown
   - This tells Git which files to ignore
3. Check the box: **"Choose a license"**
   - Select **"MIT License"** from the dropdown
   - This allows others to use your code freely

### Step 3: Create the Repository

1. Scroll to the bottom of the form
2. Click the blue **"Create repository"** button
3. GitHub will create your repository
4. You'll be taken to your new repository page
5. Congratulations! Your repository is created! 🎉

## What You'll See After Creation

After creating your repository, you'll see:

- **Repository name** at the top (e.g., "nurse-roster-manager")
- **Code tab** (shows your files)
- **Issues tab** (for bug tracking)
- **Pull requests tab** (for code review)
- **Settings tab** (repository configuration)
- A green **"Code"** button (for cloning or downloading)
- A **"README.md"** file (your project description)

## Method 2: Create Repository via Command Line (Advanced)

If you're comfortable with terminal/command prompt, you can create a repository locally and push it to GitHub.

### Step 1: Initialize Git Locally

```bash
cd /path/to/nurse-roster-manager
git init
git add .
git commit -m "Initial commit"
```

### Step 2: Create Repository on GitHub

1. Go to https://github.com/new
2. Fill in the details (same as Method 1)
3. **Don't** check "Initialize this repository with a README"
4. Click "Create repository"

### Step 3: Push Your Code

GitHub will show you commands to run. Copy and paste them:

```bash
git remote add origin https://github.com/YOUR_USERNAME/nurse-roster-manager.git
git branch -M main
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

## Next: Upload Your Code to the Repository

After creating your repository, you need to upload your Nurse Roster Manager code. You have two options:

### Option A: Upload via GitHub Website (Easiest)

1. Go to your repository on GitHub
2. Click the green **"Code"** button
3. Click **"Upload files"**
4. Drag and drop your project files into the upload area
5. Or click "choose your files" and select them manually
6. Scroll down and click **"Commit changes"**
7. Your files are now on GitHub!

### Option B: Upload via Command Line (Recommended for Developers)

```bash
cd /path/to/nurse-roster-manager
git remote add origin https://github.com/YOUR_USERNAME/nurse-roster-manager.git
git branch -M main
git push -u origin main
```

## Verify Your Repository

After uploading, verify everything is correct:

1. Go to your repository URL: `https://github.com/YOUR_USERNAME/nurse-roster-manager`
2. You should see:
   - ✓ Your project files listed
   - ✓ README.md file displayed
   - ✓ .gitignore file present
   - ✓ MIT License file present
3. If everything looks good, you're ready to deploy to Netlify!

## Repository Settings (Optional)

You can customize your repository in the **Settings** tab:

### Enable GitHub Pages (Optional)
1. Go to **Settings** → **Pages**
2. Select **"Deploy from a branch"**
3. Choose **"main"** branch
4. Your repository gets a GitHub Pages URL

### Add Topics (Optional)
1. Go to **Settings** → **General**
2. Scroll to "Topics"
3. Add relevant topics: `nurse-scheduling`, `healthcare`, `roster-management`
4. This helps people find your project

### Enable Discussions (Optional)
1. Go to **Settings** → **Features**
2. Check **"Discussions"**
3. This lets people ask questions about your project

## Important Repository URLs

After creating your repository, you'll have these important URLs:

| URL Type | Example | Purpose |
|----------|---------|---------|
| Repository URL | `https://github.com/yourname/nurse-roster-manager` | View your repository |
| Clone URL (HTTPS) | `https://github.com/yourname/nurse-roster-manager.git` | Clone to your computer |
| Clone URL (SSH) | `git@github.com:yourname/nurse-roster-manager.git` | Clone using SSH key |
| GitHub Pages | `https://yourname.github.io/nurse-roster-manager` | Static site hosting |

## Troubleshooting

### Repository Name Already Taken
- GitHub usernames are unique across the entire platform
- Try adding a number or description: `nurse-roster-manager-app`
- Or use your username: `yourname-nurse-roster`

### Can't Find the Create Repository Button
- Make sure you're logged into GitHub
- Go directly to https://github.com/new
- If that doesn't work, click your profile icon → "Your repositories" → "New"

### Upload Failed
- Check file size (GitHub has limits on individual files)
- Try uploading fewer files at once
- Use command line method instead

### Repository Appears Empty
- Make sure you committed your changes
- Refresh the page (Ctrl+R or Cmd+R)
- Check that files were actually uploaded

## Best Practices

When creating your repository:

1. **Use descriptive names**: `nurse-roster-manager` (good) vs `project1` (bad)
2. **Write a good README**: Explain what your project does
3. **Add a license**: MIT License is good for open-source projects
4. **Use .gitignore**: Prevents uploading unnecessary files
5. **Keep it organized**: Use folders for different parts of your project
6. **Document everything**: Add comments and documentation

## Security Considerations

When uploading your code:

1. **Don't commit secrets**: Never upload API keys or passwords
2. **Use .gitignore**: Exclude sensitive files
3. **Check privacy settings**: Make sure you want it public
4. **Review before uploading**: Check what files you're uploading
5. **Use environment variables**: For sensitive configuration

## Next Steps

After creating your repository and uploading your code:

1. **Deploy to Netlify** (follow NETLIFY_DEPLOYMENT.md)
2. **Set up continuous deployment** (automatic updates)
3. **Add custom domain** (optional)
4. **Start selling your app!** 🚀

## FAQ

**Q: Can I change my repository name?**
A: Yes! Go to Settings → General → Repository name. But this changes your repository URL.

**Q: Can I delete my repository?**
A: Yes! Go to Settings → Danger Zone → Delete this repository. This is permanent!

**Q: Can I make my repository private?**
A: Yes! Go to Settings → General → Change repository visibility to Private.

**Q: How do I add collaborators?**
A: Go to Settings → Collaborators → Add people. They can then contribute to your project.

**Q: Can I transfer my repository to someone else?**
A: Yes! Go to Settings → Danger Zone → Transfer ownership.

**Q: What's the difference between forking and cloning?**
A: Cloning copies the repository to your computer. Forking creates a copy on your GitHub account.

## Support

If you get stuck:

1. **GitHub Documentation**: https://docs.github.com/en/repositories
2. **GitHub Support**: https://support.github.com
3. **GitHub Community**: https://github.com/github/community/discussions

---

**Congratulations!** You've successfully created a GitHub repository! 🎉

**Next step:** Upload your Nurse Roster Manager code and deploy to Netlify.
