# Deploy to Netlify - Complete Guide

This guide will help you deploy your Nurse Roster Manager to Netlify in just a few minutes.

## Prerequisites

Before starting, you need:
1. A GitHub account (free at github.com)
2. A Netlify account (free at netlify.com)
3. This repository code on GitHub

## Step 1: Create a GitHub Account (5 minutes)

If you already have a GitHub account, skip to Step 2.

1. Go to **https://github.com**
2. Click the **"Sign up"** button (top right)
3. Enter your email address
4. Create a strong password
5. Choose a username (this will be in your repository URL)
6. Click **"Create account"**
7. Verify your email address
8. Done!

## Step 2: Create a GitHub Repository

1. Go to **https://github.com/new**
2. Fill in the form:
   - **Repository name**: `nurse-roster-manager`
   - **Description**: `Modern web app for managing nurse schedules and shift assignments`
   - **Public** (selected by default - this is fine)
   - Check **"Add a README file"**
3. Click **"Create repository"**
4. Done! Your repository is created

## Step 3: Upload Code to GitHub

You have two options:

### Option A: Using Git Command Line (Recommended)

1. Open your terminal/command prompt
2. Navigate to your project folder:
   ```bash
   cd /path/to/nurse-roster-manager
   ```

3. Add the remote repository:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/nurse-roster-manager.git
   git branch -M main
   ```

4. Push your code:
   ```bash
   git push -u origin main
   ```

5. Enter your GitHub username and password (or personal access token)
6. Done! Your code is now on GitHub

### Option B: Upload via GitHub Web Interface

1. Go to your repository on GitHub
2. Click **"Add file"** → **"Upload files"**
3. Drag and drop all files from your project folder
4. Click **"Commit changes"**
5. Done!

## Step 4: Deploy to Netlify (3 minutes)

1. Go to **https://netlify.com**
2. Click **"Sign up"** (top right)
3. Click **"GitHub"** to sign up with GitHub
4. Click **"Authorize Netlify"** when prompted
5. You'll see your GitHub repositories
6. Find **"nurse-roster-manager"** and click **"Connect"**
7. Netlify will show deployment settings:
   - **Build command**: `pnpm build`
   - **Publish directory**: `dist`
   - Click **"Deploy site"**
8. Wait 2-3 minutes for deployment to complete
9. You'll get a URL like: `https://random-name-12345.netlify.app`
10. Done! Your app is live!

## Step 5: Add a Custom Domain (Optional but Recommended)

### Buy a Domain

1. Go to **Namecheap.com**, **GoDaddy.com**, or **Google Domains**
2. Search for your desired domain name
3. Add to cart and complete purchase
4. You'll receive domain credentials

### Connect Domain to Netlify

1. In Netlify dashboard, click your site
2. Go to **"Domain settings"**
3. Click **"Add custom domain"**
4. Enter your domain name (e.g., `nurserostermanager.com`)
5. Click **"Verify"**
6. Netlify will give you nameserver addresses
7. Go to your domain registrar (Namecheap, GoDaddy, etc.)
8. Update nameservers to Netlify's nameservers
9. Wait 24-48 hours for DNS to propagate
10. Your domain is now connected!

## Step 6: Set Up Continuous Deployment

Great news! Netlify automatically deploys whenever you push code to GitHub.

To update your live app:
1. Make changes to your code
2. Commit and push to GitHub:
   ```bash
   git add .
   git commit -m "Your message here"
   git push
   ```
3. Netlify automatically rebuilds and deploys
4. Your changes are live in 1-2 minutes!

## Troubleshooting

### Build Fails
- Check build logs in Netlify dashboard
- Ensure `package.json` exists in root directory
- Verify `pnpm build` command works locally

### Site Shows 404
- Check "Publish directory" is set to `dist`
- Clear browser cache (Ctrl+Shift+Del)
- Wait 5 minutes for cache to clear

### Domain Not Working
- Check DNS propagation at **whatsmydns.net**
- Verify nameservers in domain registrar
- Wait up to 48 hours for DNS to propagate

### Need Help?
- Netlify Support: https://support.netlify.com
- GitHub Help: https://docs.github.com
- Create an issue in your repository

## Next Steps

### Monetize Your App

Now that your app is live, you can start selling it!

**Pricing Ideas:**
- **Basic Plan**: $49/month (up to 20 nurses)
- **Pro Plan**: $99/month (up to 50 nurses)
- **Enterprise**: Custom pricing

**To Add Payment Processing:**
1. Install Stripe (payment processor)
2. Add payment page to your app
3. Start accepting payments
4. Get paid monthly!

### Marketing Your App

1. **Create a landing page** explaining features and pricing
2. **Target hospitals and clinics** in your area
3. **Offer free trial** for first month
4. **Get testimonials** from beta users
5. **List on app marketplaces** (Gumroad, AppSumo, etc.)

## Monitoring Your App

### View Analytics
- Netlify dashboard shows:
  - Number of visitors
  - Deployment history
  - Build status
  - Performance metrics

### Enable Notifications
- Get alerts when builds fail
- Get alerts when site goes down
- Configure in Netlify settings

## Security

Your app is automatically:
- Protected with HTTPS (SSL certificate)
- Backed up daily
- Monitored for uptime
- Protected from DDoS attacks

## Performance

Your app will be:
- Served from CDN (fast globally)
- Cached for instant loading
- Optimized for mobile
- Average load time: <1 second

## Conclusion

Congratulations! Your Nurse Roster Manager is now live on the internet and ready to sell!

**Next steps:**
1. Test your app thoroughly
2. Set up payment processing
3. Create marketing materials
4. Start reaching out to hospitals/clinics
5. Launch your business!

Good luck! 🚀
